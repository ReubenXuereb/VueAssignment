<template>
  <display-data 
    :name="user.name"
    :age="user.age"
    :gender="user.gender"
    :interest="user.interest"
    :how="user.how"
    :confirm="user.confirm">
    </display-data>
  <the-form @set-data="setUserData"></the-form>
</template>

<script>
import TheForm from './components/TheForm.vue';
import DisplayData from './components/DisplayData.vue';

export default {
  data() {
    return {
      user: {
        name: "",
        age: "",
        gender: "",
        interest: [],
        how: "",
        confirm: ""
      },
    };
  },
  components: {
    TheForm,
    DisplayData
  },
  methods:{
    setUserData(name2, age2, gender2, interest2, how2, confirm2) {
      //console.log("Heyyyyyy " + name2 + " " + age2 + " " + gender2 + " " + interest2 + " " + how2 + " " + confirm2);
      this.user = {
        name: name2,
        age: age2,
        gender: gender2,
        interest: interest2,
        how: how2,
        confirm: confirm2
      };
    }
  }  
}
</script>

<style>

* {
  box-sizing: border-box;
}

html {
  font-family: sans-serif;
}

body {
  margin: 0;
}
</style>