<template>
  <section v-if="name !== ''">
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Age</th>
      <th scope="col">Gender</th>
      <th scope="col" v-for="int in interest" :key="int">Interest</th>
      <th scope="col">How</th>
      <th scope="col">Confirm</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>{{name}}</td>
      <td>{{age}}</td>
      <td>{{gender}}</td>
      <td v-for="int in interest" :key="int">
      {{ int }}
      </td>
       <!--<td>{{interest}}</td>-->
      <td>{{how}}</td>
      <td>{{confirm}}</td>
    </tr>
  </tbody>
</table>
  </section>
</template>

<script>
export default {
  props: {
    name: {
      type: String,
      required: true
    },
    age: {
      type: String,
      required: true
    },
    gender:{
      type: String
    },
    interest: {
      type: Array
    },
    how:{
      type:String
    },
    confirm:{
      type:Boolean
    }
  }
};
</script>

<style scoped>
section {
  margin: 2rem auto;
  max-width: 60rem;
  border-radius: 12px;
  border: 1px solid #ccc;
  padding: 1rem;
}
</style>