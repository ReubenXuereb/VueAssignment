<template>
<div class="container">
    <form @submit.prevent="submitForm">
    <h2>Contact Us</h2>
      <div class="form-group row">
        <label for="name" class="col-md-1 col-form-label">Name</label>
        <div class="col-sm-6">
          <input @blur="$v.name.$touch()" id="name" class="form-control" type="text" v-model.trim="name"/>
          <div v-if="$v.name.$error">
            <div v-for="(error, index) of $v.name.$errors" :key="index">
                <div class="text-danger">{{ error.$message }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="form-group row">
        <label for="age" class="col-md-1 col-form-label">Age</label>
        <div class="col-sm-6">
          <input @blur="$v.age.$touch()" id="name" class="form-control" type="text" v-model.trim="age"/>
          <div v-if="$v.age.$error">
            <div v-for="(error, index) of $v.age.$errors" :key="index">
                <div class="text-danger">{{ error.$message }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="form-group row">
        <label for="name" class="col-md-1 col-form-label">Gender</label>
        <div class="col-sm-6">
          <select @blur="$v.gender.$touch()" id="gender" name="gender" class="form-control" v-model.trim="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
          <div v-if="$v.gender.$error">
            <div v-for="(error, index) of $v.gender.$errors" :key="index">
                <div class="text-danger">{{ error.$message }}</div>
            </div>
          </div>
        </div>
      </div>
    <div class="form-group col-md-6">
      <label>What are you interested in?</label>
      <div class="form-check col-md-6">
        <input @blur="$v.interest.$touch()" class="form-check-input" id="interest-politics" name="interest" type="checkbox" value="Politics" v-model="interest" />
        <label class="form-check-label" for="interest-politics">Politics</label>
      </div>
      <div class="form-check col-md-6">
        <input @blur="$v.interest.$touch()" class="form-check-input" id="interest-sports" name="interest" type="checkbox" value="Sports" v-model="interest"/>
        <label class="form-check-label" for="interest-sports">Sports</label>
      </div>
      <div class="form-check col-md-6">
        <input @blur="$v.interest.$touch()" class="form-check-input" id="interest-nothing" name="interest" type="checkbox" value="Nothing" v-model="interest"/>
        <label class="form-check-label" for="interest-nothing">Nothing</label>
      </div>
      <div v-if="$v.interest.$error">
        <div v-for="(error, index) of $v.interest.$errors" :key="index">
            <div class="text-danger">{{ error.$message }}</div>
        </div>
      </div>
    </div>
    <div class="form-group col-md-6">
      <label for="how">Preferred way of learning</label>
      <div class="form-check col-md-6">
        <input @blur="$v.how.$touch()" type="radio" class="form-check-input" id="online" name="how"  value="Online" v-model="how" />
        <label class="form-check-label" for="online">Online</label>
      </div>
      <div class="form-check col-md-6">
        <input @blur="$v.how.$touch()" class="form-check-input" id="physical" name="how" type="radio" value="Pysical" v-model="how" />
        <label class="form-check-label" for="physical">Physical</label>
      </div>
      <div class="form-check col-md-6">
        <input @blur="$v.how.$touch()" class="form-check-input" id="other" name="how" type="radio" value="Other" v-model="how" />
        <label class="form-check-label" for="other">Other</label>
      </div>
      <div v-if="$v.how.$error">
        <div v-for="(error, index) of $v.how.$errors" :key="index">
            <div class="text-danger">{{ error.$message }}</div>
        </div>
      </div>
    </div>
    <div class="form-group row">
        <label for="confirm" class="col-md-3 col-form-label">Agree to terms?</label>
      <div class="col-sm-1">
        <input id="confirm" class="form-control" type="checkbox" v-model.trim="confirm"/>
      </div>
    </div>
   
    <div class="form-group col-md-6">
      <button type="submit" :disabled="$v.$invalid || !confirm" class="btn btn-primary">Submit</button>
      <!--<div v-if="$v.$anyError" class="text-danger">Please fill in all fields correctly.</div>-->
  </div>
  </form>
</div>
</template>

<script>
import { required, minLength, maxLength, alpha, numeric, between } from '@vuelidate/validators'
export default {
  emits: ['set-data'],
  data() {
    return {
      name: '',
      age: '',
      gender: '',
      interest: [],
      how: '',
      confirm: ''
    };
  },
  validations(){
    return{
      name:{required, minLength: minLength(4), maxLength: maxLength(15), alpha},
      age:{required, numeric, between: between(1,100)},
      gender:{required},
      interest:{required},
      how:{required},
      confirm:{required}
    }
  },
  methods: {
    submitForm() {
      console.log('Name: ' + this.name);
      console.log('Age: ' + this.age);
      console.log('Gender: ' + this.gender);
      //this.gender = 'male';
      console.log('Checkboxes');
      console.log(this.interest);
      console.log('Radio buttons');
      console.log(this.how);
      //this.interest = [];
      //this.how = null;
      console.log('Agree to terms');
      console.log(this.confirm);
      //this.confirm = false;
      this.$emit('set-data', this.name,  this.age, this.gender, this.interest, this.how, this.confirm );
    },
  },
};
</script>

<!--The style block with the scoped attribute will overwrite the global 
styles and will effect this component only. -->
<style scoped>
form{
  width:70%;
  padding:5px;
  margin: auto;
}
/*form {
  margin: 2rem auto;
  max-width: 40rem;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  padding: 2rem;
  background-color: #ffffff;
}

.form-control {
  margin: 0.5rem 0;
}

label {
  font-weight: bold;
}

h2 {
  font-size: 1rem;
  margin: 0.5rem 0;
}

input,
select {
  display: block;
  width: 100%;
  font: inherit;
  margin-top: 0.5rem;
}

select {
  width: auto;
}

input[type='checkbox'],
input[type='radio'] {
  display: inline-block;
  width: auto;
  margin-right: 1rem;
}

input[type='checkbox'] + label,
input[type='radio'] + label {
  font-weight: normal;
}

button {
  font: inherit;
  border: 1px solid #0076bb;
  background-color: #0076bb;
  color: white;
  cursor: pointer;
  padding: 0.75rem 2rem;
  border-radius: 30px;
}

button:hover,
button:active {
  border-color: #002350;
  background-color: #002350;
}*/
</style>