import { createApp } from 'vue'
import {createStore } from 'vuex' 

import App from './App.vue'

const store = createStore({
    //method which returns the state object
    state(){
        // returns the object with all state data
        return {
            counter: 0
        }
    },
    mutations: {
        //will get the current state automatically as an arugment
        increment (state){
            state.counter++
        },
        increase(state, value){
            state.counter = state.counter + value
        }
    }
})

const app = createApp(App)
app.use(store)
app.mount('#app')
