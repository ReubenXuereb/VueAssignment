<template>
  <base-container title="Vuex">
    <the-counter></the-counter>
    <button @click="addOne"> Add 1 </button>
    <change-counter></change-counter>
    <add-twenty></add-twenty>
  </base-container>
</template>

<script>
import BaseContainer from './components/BaseContainer.vue';
import TheCounter from './components/TheCounter.vue';
import ChangeCounter from './components/ChangeCounter.vue';
import AddTwenty from './components/AddTwenty.vue';

export default {
  components: {
    BaseContainer,
    TheCounter,
    ChangeCounter,
    AddTwenty
  },

  methods: {
    addOne() {
      //this.$store.state.counter = this.$store.state.counter + 10
      this.$store.commit('increment')
    }
  }
};
</script>

<style>
* {
  box-sizing: border-box;
}

html {
  font-family: sans-serif;
}

body {
  margin: 0;
}
</style>